export interface Superheroe {
  id: number;
  nombre: string;
  poder: string;
  fortaleza: string;
  resistencia: string;
  debilidad: string;
  imagen_url: string;
  created_at?: string;
  esFavorito?: boolean;
}