import { Component, inject } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'superheroe-frontend';
  
  // Inyectar AuthService para acceder a las signals
  protected auth = inject(AuthService);

  logout(): void {
    this.auth.logout();
    alert('✅ Sesión cerrada correctamente');
  }
}