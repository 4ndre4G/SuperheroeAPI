import { Routes } from '@angular/router';
import { CatalogComponent } from './components/catalog/catalog.component';
import { LoginComponent } from './components/login/login.component';
import { FavoritesComponent } from './components/favorites/favorites.component';
import { AddHeroComponent } from './pages/add-hero/add-hero.component';
import { AboutComponent } from './pages/about/about/about.component';
import { UserRegistrationComponent } from './pages/user-registration/user-registration.component';

// NOTA: El componente UserRegistrationComponent NO existe aún.
// Si lo necesitas, créalo con: ng generate component pages/user-registration --skip-tests --standalone
// import { UserRegistrationComponent } from './pages/user-registration/user-registration.component';

// NOTA: El AuthGuard NO existe aún.
// Si lo necesitas, créalo con: ng generate guard guards/auth --skip-tests
// import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: 'user-registration', component: UserRegistrationComponent },
  { path: 'catalog', component: CatalogComponent },
  { path: 'login', component: LoginComponent },
  { path: 'favoritos', component: FavoritesComponent },
  { path: 'add-hero', component: AddHeroComponent },
  { path: 'about', component: AboutComponent },
  { path: '', redirectTo: '/catalog', pathMatch: 'full' },
  { path: '**', redirectTo: '/catalog' }
];