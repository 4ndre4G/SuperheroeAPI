import { Component, inject } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './services/auth.service';
import { NotifyService } from './services/notify.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  title = 'superheroes App';
  
  authService = inject(AuthService);
  private router = inject(Router);
  notify = inject(NotifyService);

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}