import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  onLogin(): void {
    if (!this.email || !this.password) {
      this.errorMessage = '❌ Completa todos los campos';
      return;
    }

    console.log('Login con:', this.email);

    this.auth.login({ email: this.email, password: this.password }).subscribe({
      next: (res: any) => {
        console.log('Respuesta:', res);
        if (res && res.token) {
          this.auth.setLoginData(res.nombre, res.token);
          alert(`✅ ¡Bienvenido ${res.nombre}!`);
          this.router.navigate(['/catalog']);
        }
      },
      error: (err) => {
        console.error('Error:', err);
        if (err.status === 401) {
          this.errorMessage = '❌ Correo o contraseña incorrectos';
        } else if (err.status === 0) {
          this.errorMessage = '❌ No se puede conectar al backend';
        } else {
          this.errorMessage = err.error?.message || 'Error al iniciar sesión';
        }
      }
    });
  }
}