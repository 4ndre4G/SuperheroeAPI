import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeroesService, Heroe } from '../../services/heroes.service';
import { FavoritesService } from '../../services/favorites.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-catalog',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.scss']
})
export class CatalogComponent implements OnInit {
  heroes: Heroe[] = [];
  loading: boolean = true;
  error: string | null = null;

  private heroesService = inject(HeroesService);
  private favoritesService = inject(FavoritesService);
  private auth = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);

  ngOnInit(): void {
    console.log('CatalogComponent - ngOnInit');
    setTimeout(() => {
      this.loadHeroes();
    }, 100);
  }

  loadHeroes(): void {
    console.log('loadHeroes - Cargando catálogo');
    this.loading = true;
    
    this.heroesService.getCatalog().subscribe({
      next: (data: Heroe[]) => {
        console.log('Datos recibidos:', data.length, 'héroes');
        this.heroes = data;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.error('Error al cargar catálogo:', err);
        this.error = 'No se pudo cargar el catálogo. ¿El backend está corriendo?';
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  addToFavorites(heroe: Heroe): void {
    console.log('addToFavorites - Héroe:', heroe.nombre, 'ID:', heroe.id);
    
    // Verificar si hay sesión
    if (!this.auth.isLoggedIn()) {
      alert('❌ Debes iniciar sesión para agregar favoritos');
      return;
    }
    
    if (!heroe.id) {
      console.error('Heroe sin ID');
      return;
    }
    
    this.favoritesService.addFavorite(heroe.id).subscribe({
      next: () => {
        heroe.esFavorito = true;
        alert(`❤️ ${heroe.nombre} añadido a favoritos`);
        this.cdr.detectChanges();
      },
      error: (err: any) => {
        console.error('Error al agregar favorito:', err);
        if (err.status === 401) {
          alert('❌ Debes iniciar sesión para agregar favoritos');
        } else if (err.status === 400) {
          alert(`⚠️ ${heroe.nombre} ya está en tus favoritos`);
          heroe.esFavorito = true;
          this.cdr.detectChanges();
        } else {
          alert('❌ Error al agregar favorito');
        }
      }
    });
  }
}