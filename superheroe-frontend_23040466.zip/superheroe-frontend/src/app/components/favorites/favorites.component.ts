import { Component, OnInit, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FavoritesService } from '../../services/favorites.service';
import { AuthService } from '../../services/auth.service';
import { Superheroe } from '../../models/superheroe.model';
import { Heroe } from '../../services/heroes.service';

@Component({
  selector: 'app-favorites',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.scss']
})
export class FavoritesComponent implements OnInit {
  favorites: Superheroe[] = [];
  loading: boolean = true;
  error: string | null = null;

  private favoritesService = inject(FavoritesService);
  private auth = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);  // ← Para forzar actualización

  ngOnInit(): void {
    console.log('FavoritesComponent - ngOnInit');
    // Pequeño delay para asegurar que el token está disponible
    setTimeout(() => {
      this.loadFavorites();
    }, 100);
  }

  loadFavorites(): void {
    console.log('loadFavorites - iniciando');
    this.loading = true;
    this.error = null;
    
    const token = this.auth.getToken();
    console.log('Token actual:', token ? 'Existe' : 'No existe');
    
    if (!token) {
      console.log('No hay token');
      this.error = 'Debes iniciar sesión para ver tus favoritos.';
      this.loading = false;
      this.cdr.detectChanges();  // ← Forzar actualización
      return;
    }
    
    console.log('Token encontrado, llamando al servicio');
    this.favoritesService.getFavorites().subscribe({
      next: (data) => {
        console.log('Datos recibidos:', data.length, 'héroes');
        this.favorites = [...data];  // ← Crear nueva referencia
        this.loading = false;
        this.cdr.detectChanges();  // ← Forzar actualización de la vista
        console.log('Vista actualizada');
      },
      error: (err) => {
        console.error('Error:', err);
        this.error = 'No se pudieron cargar tus favoritos.';
        this.loading = false;
        this.cdr.detectChanges();  // ← Forzar actualización
      }
    });
  }

  removeFavorite(heroId: number): void {
    console.log('removeFavorite - ID:', heroId);
    if (confirm('¿Quitar este héroe de tus favoritos?')) {
      this.favoritesService.removeFavorite(heroId).subscribe({
        next: () => {
          console.log('Eliminado correctamente');
          this.favorites = this.favorites.filter(h => h.id !== heroId);
          this.cdr.detectChanges();  // ← Forzar actualización
          alert('✅ Héroe eliminado de favoritos');
        },
        error: (err) => {
          console.error('Error al eliminar:', err);
          alert('❌ No se pudo eliminar');
        }
      });
    }
  }
}