import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-user-registration',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.scss']
})
export class UserRegistrationComponent {
  nombre: string = '';
  email: string = '';
  password: string = '';
  message: string = '';
  isError: boolean = false;

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  onRegister(): void {
    if (!this.nombre || !this.email || !this.password) {
      this.message = '❌ Completa todos los campos';
      this.isError = true;
      return;
    }

    console.log('Registrando:', this.email);

    this.auth.register({ nombre: this.nombre, email: this.email, password: this.password }).subscribe({
      next: () => {
        this.message = '✅ Usuario registrado con éxito. Redirigiendo al login...';
        this.isError = false;
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      },
      error: (err) => {
        console.error('Error:', err);
        this.message = err.error?.message || '❌ Error al registrar usuario';
        this.isError = true;
      }
    });
  }
}