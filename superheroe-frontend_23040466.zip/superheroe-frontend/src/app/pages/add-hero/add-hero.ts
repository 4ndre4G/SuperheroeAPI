import { Component } from '@angular/core';

@Component({
  selector: 'app-add-hero',
  imports: [],
  templateUrl: './add-hero.html',
  styleUrl: './add-hero.scss',
})
export class AddHero {}
