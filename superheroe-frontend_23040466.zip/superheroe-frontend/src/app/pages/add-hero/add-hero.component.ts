import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeroesService } from '../../services/heroes.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-hero',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-hero.component.html',
  styleUrls: ['./add-hero.component.scss']
})
export class AddHeroComponent {
  heroData = {
    nombre: '',
    poder: '',
    fortaleza: '',
    resistencia: '',
    debilidad: '',
    imagen_url: ''
  };

  private heroService = inject(HeroesService);
  private router = inject(Router);

  onSubmit(): void {
    if (!this.heroData.nombre || !this.heroData.imagen_url) {
      alert('❌ Completa todos los campos');
      return;
    }

    this.heroService.createHero(this.heroData).subscribe({
      next: () => {
        alert(`✅ ${this.heroData.nombre} agregado al catálogo`);
        this.router.navigate(['/catalog']);
      },
      error: (err) => {
        console.error('Error:', err);
        alert('❌ Error al crear héroe');
      }
    });
  }
}