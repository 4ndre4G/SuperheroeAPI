import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  currentUser = signal<{ nombre: string } | null>(null);
  private apiUrl = '/api/auth';

  constructor(private http: HttpClient) {
    const savedUser = localStorage.getItem('user_name');
    const token = localStorage.getItem('token');
    if (savedUser && token) {
      this.currentUser.set({ nombre: savedUser });
    }
  }

  // Iniciar sesión
  login(credentials: { email: string; password: string }): Observable<any> {
    console.log('AuthService.login - Enviando a:', `${this.apiUrl}/login`);
    return this.http.post(`${this.apiUrl}/login`, credentials);
  }

  // ✅ REGISTRAR NUEVO USUARIO - AGREGAR ESTO
  register(userData: { nombre: string; email: string; password: string }): Observable<any> {
    console.log('AuthService.register - Llamado para:', userData.email);
    return this.http.post(`${this.apiUrl}/register`, userData);
  }

  // Guardar datos después de login exitoso
  setLoginData(nombre: string, token: string): void {
    localStorage.setItem('token', token);
    localStorage.setItem('user_name', nombre);
    this.currentUser.set({ nombre });
  }

  // Cerrar sesión
  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user_name');
    this.currentUser.set(null);
  }

  // Verificar si hay sesión activa
  isLoggedIn(): boolean {
    return !!this.currentUser();
  }

  // Obtener el token
  getToken(): string | null {
    return localStorage.getItem('token');
  }
}