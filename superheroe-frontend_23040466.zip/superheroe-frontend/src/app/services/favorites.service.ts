import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class FavoritesService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);
  private apiUrl = 'http://localhost:3000/api/heroes/favorites';

  private getHeaders(): HttpHeaders {
    const token = this.auth.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  addFavorite(heroId: number): Observable<any> {
    return this.http.post(this.apiUrl, { heroId }, { headers: this.getHeaders() });
  }

  getFavorites(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl, { headers: this.getHeaders() });
  }

  removeFavorite(heroId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${heroId}`, { headers: this.getHeaders() });
  }
}